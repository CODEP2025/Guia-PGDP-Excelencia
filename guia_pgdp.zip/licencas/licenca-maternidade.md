# Licença Maternidade

## O que é
Afastamento remunerado assegurado à servidora gestante.