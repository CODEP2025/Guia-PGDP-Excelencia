# Abono de Permanência

## O que é
Benefício ao servidor que completou os requisitos de aposentadoria.